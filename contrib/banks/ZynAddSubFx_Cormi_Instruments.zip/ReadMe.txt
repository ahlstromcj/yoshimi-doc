Cormi Instruments V.3.0                                                                                           October  5th  2014
-----------------------

Dear friend,
here's an improved version of my instruments. 
There are three banks: sound, sound2 and noise.

I like fantasy sounds, the zyn instruments do not reflect real instruments.
Some of them are modified copies created by others.

I'm using ZynAddSubFx in almost all of my compositions. They are oriented to background sounds for narration.
The instruments want to suggest atmospheres, feelings, and they are not finalized to songs.
Often I mix two or three instruments simultaneously to produce a full sound.
Please try by your own the mix and let me know your impressions.


You can listen to some of my sounds at: 
http://www.freesound.org/search/?q=cormi&f=duration%3A%5B0+TO+*%5D&s=created+desc&advanced=1&a_username=1&g=1


Please follow the evolution of my instruments and enjoy my athmospheres by visiting my blog at:
http://cormi57.wordpress.com/

There you can find the post "How to make a sample (music) for a soundfont" and the link to download the most updated version of my instruments.




I hope you'll enjoy my work as I enjoyed those works people wanted to share with me.



my nickname:  cormi

my true name: Mirco Cortesi

my e-mail:    cormi57@yahoo.it

my blog:      http://cormi57.wordpress.com/